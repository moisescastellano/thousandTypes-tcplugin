The Thousand Types plugin - Things To do
=====================================

This is a work in progress. **Help wanted!** - in particular with Visual C++ issues.

Check also this project's [issues page](https://github.com/moisescastellano/thousand-preview-plugin/issues) and Java Plugin Interface's [issues page](https://github.com/moisescastellano/tcmd-java-plugin/issues).

Things to do
------------

 - configuration for most popular formats
 - lister plugin
 - documentation on how to incorporate all Tika parsers

Contact
----------
If you want to help with the things above, or you have any comment, suggestion or problem regarding this java plugin,
you contact me at:
 - email: moises.castellano (at) gmail.com
 - [DiskDirCrc github project issues page](https://github.com/moisescastellano/diskdircrc-tcplugin/issues)
Please specify the java plugin and the JRE version you are using.

